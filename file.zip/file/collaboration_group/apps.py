from django.apps import AppConfig


class CollaborationGroupConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'collaboration_group'
